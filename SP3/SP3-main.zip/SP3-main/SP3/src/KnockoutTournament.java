import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;

public class KnockoutTournament extends Tournament {
    private ArrayList<Team[]> matchups;

    public KnockoutTournament(String name, int ID, ArrayList<Team> teams){
        super(name, ID, teams);

    }
    }

